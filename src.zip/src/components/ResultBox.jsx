import CaesarEncode from "../cipherjsx/CeasarEncode";
import CaesarDecode from "../cipherjsx/CaesarDecode";
export default function ResultBox(props){
    
    return(
        <>
        <div className="bg-white w-3xl">
            <p>the result</p>
        <p className="bg-white">{props.process}</p>
        </div>
        </>
    )
}