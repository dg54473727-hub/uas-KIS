import ButtonHeader from "./ButtonHeader";

export default function WebHeader(){
  return (
    <>
      <div className="shadow-inner shadow-gray-500/80 flex bg-[#462a5e]">
        <h1 className="text-2xl p-6 bg-[#462a5e] text-white text-shadow-lg/30 grow">
          Tugas Cipher
        </h1>
        <div className="gap-3 flex grid-cols-3">
          <ButtonHeader name="Penjelasan" link="/home"/>
          <ButtonHeader name="Caesar" link="/caesar"/>
          <ButtonHeader name="Atbash" link="/atbash"/>
          <ButtonHeader name="Transposition" link="/transposition"/>
        </div>
      </div>
    </>
  );
}
