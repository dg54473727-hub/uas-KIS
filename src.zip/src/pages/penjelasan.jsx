export default function Penjelasan() {
  return (
    <>
      <div className="flex justify-center p-4 absolute self-center w-full">
        <div className="bg-[#363636] rounded-xs h-max-xl w-4xl justify-center text-white shadow-xl-white/50 inset-0">
          <div>
            <h1 className="text-center text-xl p-4">Caesar Cipher</h1>
            <p>
              Dalam kriptografi, sandi Caesar, atau sandi geser, kode Caesar
              atau Geseran Caesar adalah salah satu teknik enkripsi paling
              sederhana dan paling terkenal. Sandi ini termasuk sandi substitusi
              di mana setiap huruf pada teks terang (plaintext) digantikan oleh
              huruf lain yang memiliki selisih posisi tertentu dalam alfabet.
              Misalnya, jika menggunakan geseran 3, W akan menjadi Z, I menjadi
              L, dan K menjadi N sehingga teks terang "wiki" akan menjadi "ZLNL"
              pada teks tersandi. Nama Caesar diambil dari Julius Caesar,
              jenderal, konsul, dan diktator Romawi yang menggunakan sandi ini
              untuk berkomunikasi dengan para panglimanya.
            </p>
            <p>
              Langkah enkripsi oleh sandi Caesar sering dijadikan bagian dari
              penyandian yang lebih rumit, seperti sandi Vigenère, dan masih
              memiliki aplikasi modern pada sistem ROT13. Pada saat ini, seperti
              halnya sandi substitusi alfabet tunggal lainnya, sandi Caesar
              dapat dengan mudah dipecahkan dan praktis tidak memberikan
              kerahasiaan bagi pemakainya.
            </p>
          </div>
        </div>
        <div></div>
      </div>
    </>
  );
}
