import { useState } from "react";
import CaesarEncode from "../cipherjsx/CeasarEncode";
import CaesarDecode from "../cipherjsx/CaesarDecode";
import ResultBox from "../components/ResultBox";

export default function Caesar(props) {
  const [plain, setInput] = useState("");
  const [key, setKey] = useState("");
  let process = null;
  return (
    <>
      <div>
        <input
          type="text"
          placeholder="plain"
          value={plain}
          onChange={(e) => setInput(e.target.value)}
          className="bg-white m-4"
        />
        <input
          type="int"
          placeholder="key"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          className="bg-white m-4"
        />

        <button
          onClick={() => CaesarEncode(plain, key)}
          className="bg-white"
        >
          Encode
        </button>
        <button
          onClick={() => CaesarDecode(plain, key)}
          className="bg-white m-4"
        >
          Decode
        </button>
        <div>
          <p className="bg-white p-4">{process}</p>
        </div>
      </div>
    </>
  );
}
