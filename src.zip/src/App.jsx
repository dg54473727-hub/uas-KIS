import { Route, Routes } from "react-router-dom";
import "./App.css";
import Penjelasan from "./pages/penjelasan";
import WebHeader from "./components/WebHeader";
import Caesar from "./pages/Caesar";

function App(){
  return(
  <>
  <WebHeader/>
  <Routes>
    <Route path="/home/" element={<Penjelasan/>}/>
    <Route path="/caesar/" element={<Caesar/>}/>
  </Routes>
</>
)
}
export default App
